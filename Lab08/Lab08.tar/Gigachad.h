#pragma once

#include "IRace.h"

class GigaChad : public IRace {
    public:

        GigaChad() : IRace(100,100,30,100,50){}

        virtual ~GigaChad(){}

};